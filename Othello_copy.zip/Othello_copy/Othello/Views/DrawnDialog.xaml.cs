﻿using System.Windows;

namespace OthelloPresentation.Views
{
    /// <summary>
    /// Interaction logic for DrawDialog.xaml
    /// </summary>
    public partial class DrawnDialog : Window
    {
        public DrawnDialog()
        {
            InitializeComponent();
        }
    }
}
