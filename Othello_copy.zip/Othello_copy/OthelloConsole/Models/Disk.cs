﻿namespace OthelloConsole.Models
{
    public enum Disk
    {
        BLANK,
        BLACK,
        WHITE
    }
}
