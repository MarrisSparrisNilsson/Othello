﻿namespace OthelloBusiness.Models
{
    public enum Disk
    {
        BLANK,
        BLACK,
        WHITE
    }
}
